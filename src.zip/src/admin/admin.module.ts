import { Module } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Users } from 'src/users/users.entity';
import { AdminAction } from './adminAction.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Users,AdminAction])],
  providers: [AdminService],
  controllers: [AdminController]
})
export class AdminModule {}
