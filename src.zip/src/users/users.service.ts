import { Injectable, NotFoundException } from '@nestjs/common';
import { Users } from './users.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateUserDto } from './createUsers.dto';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(Users)
    private userRepository: Repository<Users>,
  ) {}

  async createUser(user: CreateUserDto): Promise<Users> {
    const save = this.userRepository.create(user);
    return await this.userRepository.save(save);
  }

  async findAll(): Promise<Users[]> {
    return await this.userRepository.find();
  }

  async findOne(id: string): Promise<Users> {
    const user = await this.userRepository.findOne({ where: { userID: id } });
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async update(id: string, data: CreateUserDto): Promise<Users> {
    const user = await this.findOne(id); // Ensures user exists
    Object.assign(user, data);
    return await this.userRepository.save(user);
  }

  async remove(id: string): Promise<{ message: string }> {
    const result = await this.userRepository.delete(id);
    if (result.affected === 0) throw new NotFoundException('Users not found');
    return { message: 'User deleted successfully' };
  }
}
